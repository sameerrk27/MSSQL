use case_study

-- case study 1

-- 1) Reterieve all data 
select * from Fact; -- mathematical & numerical related info like (sales,profit,bonus,etc)
select * from [Location ];  -- area state city related info
select * from Product; -- product details related info like (p_name,p_type,p_id)


-- 2) Display the number of states present in location table
-- distinct : returns unique states rather than returning multiple_times repeated(duplicate) states
-- before using distinct -> duplicates are also get counted, 
--    ex -  in a the states(col) maharashtra repeated 2 times: it is duplicate but still it get counted 2 times
-- after using distinct -> it return unique states
         -- to avoid this duplication we use Distinct
select count(distinct State) as Total_States from dbo.[Location ];


-- 3) How many products are of regular type 
-- want all the products of reg_type : do not mention distinct over here!
select count(*) as Total_Regular_Type
from Product
where type = 'Regular'


-- 4) Minimum sales vals of a product 
select min(Sales) as Minimum_Sales from Fact


-- 5) Display the details of the product where product_type is coffee
select *  from Product
where Product_Type='coffee'


-- 6) What is the Average Sales in Area Code 719
select avg(sales) as Average_Sales from Fact
where Area_Code = '719';


-- 7) Find out total profit generate by Coloardo state
select sum(F.Sales) as Total_Profit
from  fact F
JOIN dbo.[Location ] AS L
ON F.Area_Code = L.Area_Code
where State = 'Colorado'


-- 8) Display the average budget of the product where the average budget margin should be greater than 100
select ProductId,AVG(Budget_Profit) as average_budget
from Fact
group by ProductId
having AVG(Budget_Margin)>100;


-- 9) what is the total sales done on 2010-01-01 ?
select sum(sales) as Total_Sales
from Fact
where Date = '2010-01-01';


-- 10) display a table with the attributes : date,productid,producttype, productsales,profit,state,areacode;
-- product table : productid,productype,
-- fact table : productid,date,productsales,profit,areacode
-- location table : state,areacode
select * from Fact
select * from [Location ]
select * from Product

select f.Date ,f.ProductId,p.Product,p.Product_Type,f.Sales,f.Profit,l.State,l.Area_Code
from Fact f
JOIN Product p
ON f.ProductId = p.ProductId
JOIN [Location ] as l
ON f.Area_Code = l.Area_Code


-- 11) display the rank without any gap to show sales-wise rank
-- dense rank : - doesn't skip a rank
 -- ex        : - it continues further like 1,2,2,2,2,3,3
-- rank : - skips the rank in between 
 -- ex  : - like 1,1,1,4,4,6,7,7,7,7,11
select *,DENSE_RANK() over (order by sales desc) as Sales_Wise_Rank
from Fact


-- 12) If there is an increase in sales of 5%, calculate the increasedsales.
-- 5% = 5/100 = 0.05
-- now we want to calculate this increased 0.05% : Sales + 0.05 [5%]
-- lets consider this sales as                       1   + 0.05 = 1.05%
--                                                 Sales * 1.05 
select ProductId,
Sales,
Sales * 1.05 as Increased_Sales 
from Fact;


-- 13) Create a stored procedure to fetch the result according to theproduct type from ProductTable.
GO
CREATE PROCEDURE Get_Products
     @pdt_type varchar(50)
AS
BEGIN 
    SELECT *
    FROM Product
    WHERE Product_Type= @pdt_type
END;

EXEC Get_Products 'Coffee';



-- 14) change the product type from coffee to tea where product id is 1 and then undo the change
BEGIN TRANSACTION
update Product
set Product_Type = 'tea'
where Productid = 1

select *
from Product
where ProductId = 1;

ROLLBACK TRANSACTION


